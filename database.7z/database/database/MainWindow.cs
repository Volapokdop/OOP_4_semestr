﻿//Автор: Подкопалов Андрей

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.SqlTypes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Security.Policy;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.InteropServices;

namespace database
{
    //создаём класса работы с окном
    public partial class MainWindow : Form
    {
        //сборщик мусора автоматический, самому вручную удалять не надо
        //создаём экземпляр класса управления таблицей, tc будет содержать ссылку на объект
        private TableControle tc = new TableControle();
        
        public MainWindow()
        {
            InitializeComponent();
            //привязываем отображение к таблице
            dataView.DataSource = tc.get_table();
        }

        // вставляем данные
        private void insert_buttonClick(object sender, EventArgs e)
        {
            //вставляем данные в таблицу
            tc.add_table(nameTextBox.Text, surnameTextBox.Text, ageTextBox.Text, phoneTextBox.Text);
        }

        //изменить выбранную строку
        private void changeButton_Click(object sender, EventArgs e)
        {
            //изменям
            tc.change_table(nameTextBox.Text, surnameTextBox.Text, ageTextBox.Text, 
                phoneTextBox.Text, dataView.SelectedCells[0].RowIndex);
        }

        // очистить всё
        private void clearAllButton_Click(object sender, EventArgs e)
        {
            //удаляем всё
            tc.delete_all_table();
        }

        //удалить выбранную строку
        private void clearSelectedButton_Click(object sender, EventArgs e)
        {
            //передаём индекс текущей строки и удаляем выбранную строку
            tc.delete_select_table(dataView.SelectedCells[0].RowIndex);
        }

        // сохранение базы
        private void SaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создаём диалоговое окно для сохранения
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            //проверяется, что нажато "ок"
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                {
                    //пробуем сохранить базу в файл
                    try
                    {
                        tc.save_file_table(saveFileDialog.FileName);
                    }

                    //исключение, когда файл является проблемным (только для чтения и т.п)
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        // открытие файла
        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //создаём диалоговое окно общения
            OpenFileDialog openFileDialog = new OpenFileDialog();
            //проверка, что пользователь нажал "ок"
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //пробуем открыть базу из файла
                try
                {
                    tc.open_file_table(openFileDialog.FileName);
                }
                //исключение, когда файл является проблемным (только для чтения и т.п)
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //проверка, что мы ввели букву
        private void input_word_check(System.Windows.Forms.TextBox box, KeyPressEventArgs e)
        {
            //переменная, хранящая нажатый символ
            char ch = e.KeyChar;
            //проверка, что символ это цифра
            if (Char.IsDigit(ch))
            {
                //если истинно, то не вводим
                box.BackColor = Color.LightGoldenrodYellow;
                box.ReadOnly = true;
            }
            else
            {
                //иначе вводим
                box.BackColor = Color.White;
                box.ReadOnly = false;
            }
        }

        //проверка ввода имени
        private void nameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            input_word_check(nameTextBox, e);
        }

        //проверка ввода фамилии
        private void surnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            input_word_check(surnameTextBox, e);
        }

        //проверка, что мы ввели цифру
        private void input_number_check(System.Windows.Forms.TextBox box, KeyPressEventArgs e)
        {
            //переменная, хранящая нажатый символ
            char ch = e.KeyChar;
            //проверяется, что введена либо цифра, либо клавиша backspace
            if (!Char.IsDigit(ch) && ch != 8)
            {
                //если истинно, то не вводим
                box.BackColor = Color.LightGoldenrodYellow;
                box.ReadOnly = true;
            }
            else
            {
                //иначе вводим
                box.BackColor = Color.White;
                box.ReadOnly = false;
            }
        }

        //проверка ввода возраста
        private void ageTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            input_number_check(ageTextBox, e);
        }

        //проверка ввода телефона
        private void phoneTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            input_number_check(phoneTextBox, e);
        }

        //окно о разработчике
        private void AboutDeveloperToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox box = new AboutBox();
            box.ShowDialog();
        }
    }
    }
