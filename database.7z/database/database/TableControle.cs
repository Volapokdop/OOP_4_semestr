﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Threading;
using System.Runtime.InteropServices.ComTypes;

namespace database
{
    //класс управления таблицей
    internal class TableControle
    {
        //создаём таблицу
        private DataTable table = new DataTable();
        //заполняем столбы таблицы
        public TableControle()
        {
            table.Columns.Add("Имя", typeof(SqlString));
            table.Columns.Add("Фамилия", typeof(SqlString));
            table.Columns.Add("Возраст", typeof(SqlString));
            table.Columns.Add("Номер телефона", typeof(SqlString));
        }
        //возвращаем таблицу
        public DataTable get_table()
        {
            return table;
        }

        //добавить строку в таблицу, передаём имя, фамилию, возраст и номер
        public void add_table(string name, string surname, string age, string number)
        {
            //вставляем данные в таблицу
            table.Rows.Add(name, surname, age, number);
        }
        //удалить всё из таблицы
        public void delete_all_table()
        {
            table.Rows.Clear();
        }
        //удалить выбранную строку
        public void delete_select_table(int ind)
        {
            try
            {
                table.Rows.RemoveAt(ind);//ind - индекс строки
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void change_table(string name, string surname, string age, string number, int ind)
        {
            //вставляем данные в таблицу
            try
            {
                table.Rows[ind][0] = name;
                table.Rows[ind][1] = surname;
                table.Rows[ind][2] = age;
                table.Rows[ind][3] = number;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //сохранение базы данных в текстовый файл
        public void save_file_table(string filename)
        {
            //создаём переменную для записи и связываем её с выбранным файлом
            StreamWriter myWriter = new StreamWriter(filename);
            //цикл для записи текста в файл
            for (int i = 0; i < table.Rows.Count; i++)
            {
                myWriter.Write(table.Rows[i].ToString().Split(' '));
                myWriter.Write('\r');
            }
            //закрывает поток
            myWriter.Close();
        }

        //функция открытия файла
        public void open_file_table(string fileName)
        {
                //создаём переменную для чтения и связываем её с выбранным файлом
                StreamReader myread = new StreamReader(fileName);
                //создаём массив строк, в который считываем содержимое файла
                string[] str = myread.ReadToEnd().Split('\r');
                //очистить таблицу
                table.Rows.Clear();
                //создаём переменную массива строк, в которой храним слова из одной строки
                string[] s;
                //цикл записи в таблицу
                for (int i = 0; i < str.Count(); i++)
                {
                    //добавляем в таблицу одну строку
                    table.Rows.Add();
                    //записываем каждое слово из строки в массив строк
                    s = str[i].Split(' ', '\r');
                    //цикл вставки в таблицу
                    for (int j = 0; j < str[i].Split(' ').Length; j++)
                    {
                        //вставляем в ячейку значение из строки
                        table.Rows[i][j] = s[j];
                    }
                }
                //закрываем потоки
                myread.Close();
        }
    }
}
