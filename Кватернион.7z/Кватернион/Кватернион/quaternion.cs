﻿//Автор: Подкопалов Андрей

using System;

namespace Quatern
{
    class Quaternion
    {
        //действительная часть
        private float valid;

        //мнимая часть i
        private float img1;

        //мнимая часть j
        private float img2;

        //мнимая часть k
        private float img3;


        //Конструктор по умолчанию
        public Quaternion()
        { }

        //Конструктор с параметрами
        public Quaternion(float valid, float img1, float img2, float img3)
        {
            this.Valid = valid;
            this.Img1 = img1;
            this.Img2 = img2;
            this.Img3 = img3;
        }


        //--------------------------------------------------------------------------
        //действительная часть
        public float Valid
        {
            // value - входной параметр
            get { return this.valid; }
            set { this.valid = value; }
        }
        //мнимая часть i
        public float Img1
        {
            // img1 - входной параметр
            get { return this.img1; }
            set { this.img1 = value; }
        }
        //мнимая часть j
        public float Img2
        {
            // img2 - входной параметр
            get { return this.img2; }
            set { this.img2 = value; }
        }
        //мнимая часть k
        public float Img3
        {
            // img3 - входной параметр
            get { return this.img3; }
            set { this.img3 = value; }
        }
        //--------------------------------------------------------------------------
        //Сложение
        public Quaternion Add(Quaternion f2)
        {

            this.valid = this.valid + f2.valid;
            this.img1  = this.img1 + f2.img1;
            this.img2  = this.img2 + f2.img2;
            this.img3  = this.img3 + f2.img3;
            return this;
        }

        //--------------------------------------------------------------------------
        //Вычитание
        public Quaternion Sub(Quaternion f2)
        {

            this.valid = this.valid - f2.valid;
            this.img1  = this.img1 - f2.img1;
            this.img2  = this.img2 - f2.img2;
            this.img3  = this.img3 - f2.img3;

            return this;
        }


        //--------------------------------------------------------------------------
        //Умножение  
        public Quaternion Mult(Quaternion f2)
        {
            //по формуле
            this.valid = this.valid * f2.valid - this.img1 * f2.img1 - this.img2 * f2.img2 - this.img3 * f2.img3;
            this.img1  = this.valid * f2.img1 + f2.valid * this.img1 + this.img2 * f2.img3 - f2.img2 * this.img3;
            this.img2  = this.valid * f2.img2 + f2.valid * this.img2 + this.img3 * f2.img1 - f2.img3 * this.img1;
            this.img3  = this.valid * f2.img3 + f2.valid * this.img3 + this.img1 * f2.img2 - f2.img1 * this.img2;

            return this;
        }


        //--------------------------------------------------------------------------
        //Модуль
        public double Module()
        {
            return Math.Sqrt(this.valid * this.valid + this.img1 * this.img1 + this.img2 * this.img2 + this.img3 * this.img3); ;
        }


        //--------------------------------------------------------------------------
        //Аргумент
        public double Argument() {
            return Math.Acos(this.valid / Module());
        }

        //--------------------------------------------------------------------------
        //Преобразование в строку
        public string ToString()
        {
            return (String.Format("{0}, {1}i, {2}j, {3}k", this.valid, this.img1, this.img2, this.img3));
        }
    }
}
