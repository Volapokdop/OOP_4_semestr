﻿//Автор: Подкопалов Андрей

using System;
using System.Windows;

namespace Quatern
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //объявляем экземпляры класса кватернион
        private Quaternion f1, f2;

        public MainWindow()
        {
            //создаём экземпляры класса кватернион
            f1 = new Quaternion();
            f2 = new Quaternion();
            InitializeComponent();
        }

        //функция сложения
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //считываем данные из блоков в поля класса
            f1.Valid = Convert.ToInt32(Digit11.Text);
            f1.Img1  = Convert.ToInt32(Digit12.Text);
            f1.Img2  = Convert.ToInt32(Digit13.Text);
            f1.Img3  = Convert.ToInt32(Digit14.Text);

            f2.Valid = Convert.ToInt32(Digit21.Text);
            f2.Img1  = Convert.ToInt32(Digit22.Text);
            f2.Img2  = Convert.ToInt32(Digit23.Text);
            f2.Img3  = Convert.ToInt32(Digit24.Text);

            //вызов метода сложения
            f1 = f1.Add(f2);
            //вызов метода приведения полей класса в строку
            Result.Text = (f1.ToString());
        }

        //функция вычитания
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //считываем данные из блоков в поля класса
            f1.Valid = Convert.ToInt32(Digit11.Text);
            f1.Img1  = Convert.ToInt32(Digit12.Text);
            f1.Img2  = Convert.ToInt32(Digit13.Text);
            f1.Img3  = Convert.ToInt32(Digit14.Text);

            f2.Valid = Convert.ToInt32(Digit21.Text);
            f2.Img1  = Convert.ToInt32(Digit22.Text);
            f2.Img2  = Convert.ToInt32(Digit23.Text);
            f2.Img3  = Convert.ToInt32(Digit24.Text);

            //вызов метода вычитания
            f1 = f1.Sub(f2);
            //вызов метода приведения полей класса в строку
            Result.Text = (f1.ToString());
        }

        //функция умножения
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //считываем данные из блоков в поля класса
            f1.Valid = Convert.ToInt32(Digit11.Text);
            f1.Img1  = Convert.ToInt32(Digit12.Text);
            f1.Img2  = Convert.ToInt32(Digit13.Text);
            f1.Img3  = Convert.ToInt32(Digit14.Text);

            f2.Valid = Convert.ToInt32(Digit21.Text);
            f2.Img1  = Convert.ToInt32(Digit22.Text);
            f2.Img2  = Convert.ToInt32(Digit23.Text);
            f2.Img3  = Convert.ToInt32(Digit24.Text);

            //вызов метода вычитания
            f1 = f1.Mult(f2);
            //вызов метода приведения полей класса в строку
            Result.Text = (f1.ToString());
        }
        //функция модуля
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            //считываем данные из блоков в поля класса
            f1.Valid = Convert.ToInt32(Digit11.Text);
            f1.Img1  = Convert.ToInt32(Digit12.Text);
            f1.Img2  = Convert.ToInt32(Digit13.Text);
            f1.Img3  = Convert.ToInt32(Digit14.Text);
            //вызов метода модуля и метода приведения полей класса в строку
            Result.Text = Convert.ToString(f1.Module());
        }
        //функция аргумента
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            //считываем данные из блоков в поля класса
            f1.Valid = Convert.ToInt32(Digit11.Text);
            f1.Img1  = Convert.ToInt32(Digit12.Text);
            f1.Img2  = Convert.ToInt32(Digit13.Text);
            f1.Img3  = Convert.ToInt32(Digit14.Text);
            //вызов аргумента модуля и метода приведения полей класса в строку
            Result.Text = Convert.ToString(f1.Argument());
        }
    }
}
