﻿//Автор: Подкопалов Андрей

using System;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace ChatBot1
{
    public partial class MainForm : Form        
    {
        private string text_in;             //переменная, в которой будут храниться введенные пользователем команды
        private DateTime time;              //переменная, в которой будет храниться время отправки команды 
        private Answer reply = new Answer();//создание экземпляра класса reply для использования методов обработки сообщения

        public MainForm()
        {
            //Вызов InitializeComponent() является вызовом метода к частичному классу элемента управления
            InitializeComponent();
        }

        public MainForm(LogicForm loginForm)
        {
            //Вызов InitializeComponent() является вызовом метода к частичному классу элемента управления
            InitializeComponent();
        }

        //получение имени пользователя
        public void setName(string user)
        {
            reply.userName = user;
        }

        //обработка отправленного сообщения
        private void button_input_Click(object sender, EventArgs e)
        {
            text_in = textBox_input.Text;        //переменная, к которой хранится введённая команда

            time = DateTime.Now;//время, отправки сообщения
            //вывод сообщения пользователя в richTextBox_show
            richTextBox_show.AppendText(text_in + "  (" + Convert.ToString(time.ToLongTimeString()) + ", " + reply.userName + ")" + "\r\n");

            time = DateTime.Now;//время, отправки сообщения
            //вывод ответа в richTextBox_show
            richTextBox_show.AppendText(Convert.ToString(reply.response(text_in)) + "  (" + Convert.ToString(time.ToLongTimeString()) + ", Бот )" + "\r\n");
            //очищаем поле ввода
            textBox_input.Text = "";
        }


        //сохранение истории сообщений в файл
        private void SaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Создайте saveFileDialog - класс, чтобы выбрать местоположение сохраняемого файла.
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            //поиск файлов RTF *. для пропуска символов при поиске
            saveFileDialog.Filter = "Файл rtf(*.rtf)|*.rtf";
            //проверка, что пользователь нажал "ок"
            if (saveFileDialog.ShowDialog() == DialogResult.OK)//
            {
                //создаём переменную, хранящую имя файла
                string fileName = saveFileDialog.FileName;
                //создаем переменную, в которой будет храниться текст их richTextBox_show 
                string[] richTB = richTextBox_show.Text.Split('\n');
                //обращаемся к методу класса Answer для сохранения истории сообщений в файл
                reply.saveFile(fileName);
            }
        }


        //загрузка истории сообщений из файла
        private void LoadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Создаём OpenFileDialog, класс, чтобы выбрать местоположение открываемого файла.
            OpenFileDialog openFile = new OpenFileDialog();
            // Инициализируем OpenFileDialog для поиска файлов с расширением rtf.
            openFile.DefaultExt = "*.rtf";
            //поиск файлов RTF *. для пропуска символов при поиске
            openFile.Filter = "RTF Files|*.rtf";
            //создание переменное, хранящей имя файла
            string fileName = openFile.FileName;
            // Определяем, выбрал ли пользователь файл из OpenFileDialog и есть ли у файла имя
            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK && openFile.FileName.Length > 0)
            {
                //загрузка текста в окно общения с ботом
                richTextBox_show.Text = string.Join("\n", reply.downloadFile(fileName)); 
            }
        }
    }
}
