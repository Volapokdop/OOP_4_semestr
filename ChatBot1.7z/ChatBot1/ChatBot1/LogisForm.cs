﻿//Автор: Подкопалов Андрей

using System;
using System.Windows.Forms;

namespace ChatBot1
{
    //обработка окошка с вводом имени
    public partial class LogicForm : Form
    {
        public string UserName;         //Имя пользователя

        public LogicForm()
        {
            InitializeComponent();//инициализируем
        }

        //при нажатии на клавишу "ок"
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            UserName = textBoxName.Text;           //присваиваем строковой переменной введенное имя пользователя 

            this.Hide();                           //Скрываем нынешнее окно

            MainForm newForm = new MainForm();     //Создаём экземпляр окна общения с ботом

            newForm.setName(UserName);             //Передаём в новую форму имя пользователя

            newForm.ShowDialog();                  //Вызов главного окна

            this.Close();                          //Закрываем нынешнее окно
           
        }
    }
}
