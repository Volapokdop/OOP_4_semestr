﻿//Автор: Подкопалов Андрей

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ChatBot1
{
    //Класс для получения информации о погоде и курсе валёт в отдельные классы, чтобы не нарушать принцип единственной ответственности.
    internal class Web
    {
        public Web() { 
        }
        //возвращает курс валюты
        public string currence()
        {
            //создаём переменную, которая хранит весь текст
            string line;
            //инициализируем переменную класса WebClient для работы с сетью
            using (WebClient wc = new WebClient())
                line = wc.DownloadString("http://www.cbr.ru/scripts/XML_daily.asp");//весь текст с сайта сохраняется в эту переменную
            //  a(.*?)b  - квантификатор, означающий, что мы ищем сочетание символов a и b независимо от того, сколько символов между ними
            Match match = Regex.Match(line, "<Name>Доллар США</Name><Value>(.*?)</Value>(.*?)<Name>Евро</Name><Value>(.*?)</Value>");//выделяем то, что нам нужно на сайте с помощью скобок и записываем в переменную класса Match
            //выводим ответ
            return "Доллар США: " + match.Groups[1].Value + "\r\nЕвро: " + match.Groups[3];
        }
        //возвращает температуру
        public string weather()
        {
            //url сайта погоды  lat=52.5030512&lon=113.1906471
            string url = "https://api.openweathermap.org/data/2.5/weather?q=Chita&units=metric&appid=b0122bd6d761a782617f839bf07565eb";
            //создаем запрос HTTP для записи запроса
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            //считываем все данные с Request
            HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //переменная, в которой будет храниться информация о температуре
            string response;
            //считать все данные с HttpWebResponse через StreamReader, т.е. в определённой кодировке 
            using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
            {
                //считываем текст
                response = streamReader.ReadToEnd();
            }
            //реализуем созданный нами класс погоды через метод DeserializeObjec класса JsonConvert, чтобы преобразовать строку в структуру C#
            WeatherResponse weatherResponse = JsonConvert.DeserializeObject<WeatherResponse>(response);
            //выводит ответ на запрос температуры
            return "Температура в Чите на данный момент " + weatherResponse.Main.Temp + " ˚C";
        }
    }
}
