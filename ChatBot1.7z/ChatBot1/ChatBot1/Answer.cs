﻿//Автор: Подкопалов Андрей

using System;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Windows.Forms;

namespace ChatBot1
{
    //класс обработки сообщений, общения с ботом
    class Answer
    {
        //регулярные выражения для шаблонов ответов
        private Regex hello = new Regex("привет", RegexOptions.IgnoreCase); 
        private Regex doing = new Regex("дела", RegexOptions.IgnoreCase);
        private Regex time = new Regex("время", RegexOptions.IgnoreCase);
        private Regex date = new Regex("дата", RegexOptions.IgnoreCase);
        private Regex day = new Regex("день", RegexOptions.IgnoreCase);
        //Символ @ помогает считывать служебный символ не как служебный символ 
        private Regex sum = new Regex(@"сумм\w*", RegexOptions.IgnoreCase);
        private Regex sub = new Regex(@"выч\w*", RegexOptions.IgnoreCase);
        private Regex mult = new Regex(@"умнож\w*", RegexOptions.IgnoreCase);
        private Regex div = new Regex(@"раздел\w*", RegexOptions.IgnoreCase);
        private Regex weatherIn = new Regex("погода", RegexOptions.IgnoreCase);
        private Regex currencyIn = new Regex("курс", RegexOptions.IgnoreCase);
        private string[] messages;    //переменная, в которой будет храниться история сообщений
        public string userName;     //имя пользователя

        //*************************************************************************************
        //Возвращает время, установленное на компьютере
        public string timeNow()       
        {
            DateTime now = DateTime.Now;
            return Convert.ToString(now.ToLongTimeString());
        }

//*************************************************************************************
        //Возвращает дату, установленное на компьютере
        public string dateNow()      
        {
            DateTime now = DateTime.Now;
            return Convert.ToString(now.ToLongDateString());
        }

//*************************************************************************************
        //Возвращает день недели
        public string dayNow()       
        {
            DateTime now = DateTime.Now;
            return Convert.ToString(now.DayOfWeek);
        }

//*************************************************************************************
        //Возвращает сумму чисел
        public string operationSum(string text)    
        {
            string[] s1 = text.Split(' ');      //массив из слов
            int num1 = Convert.ToInt32(s1[1]);
            int num2 = Convert.ToInt32(s1[2]);

            return Convert.ToString(num1 + num2);
        }

//*************************************************************************************
        //Возвращает разность чисел
        public string operationSubt(string text)   
        {
            string[] s1 = text.Split(' ');
            int num1 = Convert.ToInt32(s1[1]);
            int num2 = Convert.ToInt32(s1[2]);

            return Convert.ToString(num1 - num2);
        }

//*************************************************************************************
        //Возвращает произведение чисел
        public string operationMult(string text)   
        {
            string[] s1 = text.Split(' ');
            int num1 = Convert.ToInt32(s1[1]);
            int num2 = Convert.ToInt32(s1[2]);

            return Convert.ToString(num1 * num2);
        }

//*************************************************************************************
        //Возвращает частное от деления чисел
        public string operationDiv(string text) 
        {
            string[] s1 = text.Split(' ');
            int num1 = Convert.ToInt32(s1[1]);
            int num2 = Convert.ToInt32(s1[2]);

            return Convert.ToString(num1 / num2);
        }

//*******************************************************************************************************************************************
        //получение погоды в городе
        public string weather()                
        {
            Web w = new Web();
            return w.weather();
        }

//********************************************************************************************************************************************
        //вовращает курс валют, а именно доллар США и евро
        public string currency()                
        {
            Web w = new Web();
            return w.currence();
        }

//****************************************************************************************************************************************************
        //Запись истории сообщений в файл
        public void saveFile(string fileName)
        {
            //Создаём экземпляр класса StreamWriter, производного от TextWriter, для записи данных в поток
            StreamWriter streamwriter = new System.IO.StreamWriter(fileName, false, System.Text.Encoding.GetEncoding("utf-8"));
            //записываем историю сообщений в файл
            streamwriter.Write(string.Join("\n", messages));
            streamwriter.Close();
        }

//****************************************************************************************************************************************************
        //загрузка истории сообщений из файла
        public string[] downloadFile(string fileName)
        {
            //Создаём экземпляр класса StreamReader, для чтения данных из файла в поток
            StreamReader streamReader = new System.IO.StreamReader(fileName);   
            //Открывает текстовый файл, считывает весь текст файла и затем закрывает файл.
            messages = streamReader.ReadToEnd().Split('\n');
            return messages;
        }


//******************************************************************************************************************************************************
        //метод, в котором обрабатываются сообщения
        public string response(string text_in)
        {
            //время ответа бота
            DateTime time;
            //случайная переменная, определяющая один из ответов на запрос
            Random rnd = new Random();
            //массив из ответов на приветствие от пользователя
            string[] answersHello = { "Дороу", "Дратути", "Привет!" };
            //ответ, если введена незнакомая команда
            string result = "Данной функции нет!";
            //если в веденной строке, обнаружено соответствие одному из регулярных выражений
            if (hello.IsMatch(text_in))    //приветствие
            {
                switch (rnd.Next(0, 2)) //рандомно выбирается ответ на приветствие
                {
                    case 0:  
                        result= answersHello[0]; //выводит Дороу
                        break;
                    case 1: 
                        result = answersHello[1]; //выводит Дратути
                        break;       
                    case 2: 
                        result = answersHello[2]; //выводит Привет
                        break;
                }
            }
            else if (doing.IsMatch(text_in))   //ответ на вопрос "Как дела?"
            {
                switch (rnd.Next(0, 1))        //случайно выводится один из ответов
                {
                    case 0:
                        result = "Все отлично!";
                        break;
                    case 1:
                        result = "Все хорошо!";
                        break;
                }
            }
            else if (this.time.IsMatch(text_in))    //ответ на вопрос о времени
            {
                result = timeNow();        
            }
            else if (date.IsMatch(text_in))    //ответ на вопрос о дате 
            {
                result = dateNow();
            }
            else if (day.IsMatch(text_in))     //ответ на вопрос о дне недели
            {
                result = dayNow();
            }
            else if (sum.IsMatch(text_in))     //ответ на команду о сложении
            {
                result = operationSum(text_in);
            }
            else if (sub.IsMatch(text_in))     //ответ на команду о вычитании
            {
                result = operationSubt(text_in);
            }
            else if (mult.IsMatch(text_in))    //ответ на команду об умножении        
            {
                result = operationMult(text_in);
            }
            else if (div.IsMatch(text_in))     //ответ на команду о делении
            {
                result = operationDiv(text_in);
            }
            else if (weatherIn.IsMatch(text_in))//ответ на команду о погоде
            {
                result = weather();
            }
            else if (currencyIn.IsMatch(text_in))//ответ на команду о курсах валют
            {
                result = currency();
            }

            //время получения ответа от бота
            time = DateTime.Now;
            //увеличиваем размер массива сообещний
            Array.Resize(ref messages, messages.Length + 1);
            //история сообщений
            messages[messages.Length - 1] = text_in + "(" + Convert.ToString(time.ToLongTimeString()) + ", " + userName + ")" + "\n\r" + result + "(" + Convert.ToString(time.ToLongTimeString()) + ", Бот )";
            //возвращаем ответ от бота
            return result;
        }
    }
}
