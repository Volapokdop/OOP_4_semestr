﻿//Автор: Подкопалов Андрей

//В связи с особенностями метода JsonConvert.DeserializeObject приходится использовать вложенный класс
namespace ChatBot1
{
    //класс температуры
    class TemperatureInfo
    {
        //отвечает за структуру 2 вложенности json ответа
        public float Temp;
    }
    //класс погоды
    class WeatherResponse
    {
        //отвечает за структуру 1 вложенности json ответа
        public TemperatureInfo Main;
    }

}
